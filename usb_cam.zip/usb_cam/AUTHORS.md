Original Authors
----------------
 * Benjamin Pitzer (benjamin.pitzer@bosch.com)

Maintainers
------------
 * [Andrey Vukolov](https://github.com/twdragon) (andrey.vukolov@elettra.eu)
 * [Shingo Kitagawa](https://github.com/knorth55)
 * [Evan Flynn](https://github.com/flynneva) - for ROS2 development branch
 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * ROS Orphaned Package Maintainers
 
 Contributors
 ------------
  * [Adrian Cooke](https://github.com/agcooke)
  * [Kei Okada](https://github.com/k-okada)
  * [Cassie Kent](https://github.com/dekent)
  * [FriedCircuits](https://github.com/FriedCircuits)
  * [Ludovico Russo](https://github.com/ludusrusso)
  * [Benjamin Maidel](https://github.com/benmaidel)

